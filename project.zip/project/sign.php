<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "details";
$email = $_POST['email'];
$name = $_POST['name'];
$message = $_POST['message'];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO details(name,email, message)
VALUES ('$name','$email', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
	header('location:contact.html');
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>